bob = {'name': 'Bob Smith', 'age': 34, 'pay': 30000, 'job': 'dev'}
sue = {'name': 'Sue Jones', 'age': 44, 'pay': 450000, 'job': 'ceo')
tom = {'name': 'Tom Argano', 'age': 59, 'pay': 200000, 'job': 'politcal hack'}
